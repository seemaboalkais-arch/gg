package com.sarmad.keyboard

import android.inputmethodservice.InputMethodService
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.widget.Button
import android.widget.LinearLayout
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class SarmadIME : InputMethodService() {

    private lateinit var aiEngine: AIEngine
    private val scope = CoroutineScope(Dispatchers.Main)

    override fun onCreate() {
        super.onCreate()
        aiEngine = AIEngine()
    }

    override fun onCreateInputView(): View {
        val keyboardView = layoutInflater.inflate(R.layout.keyboard_view, null)
        
        val btnCorrect = keyboardView.findViewById<Button>(R.id.btn_correct)
        val btnRefine = keyboardView.findViewById<Button>(R.id.btn_refine)

        btnCorrect.setOnClickListener { processText(AIEngine.Mode.CORRECT) }
        btnRefine.setOnClickListener { processText(AIEngine.Mode.REFINE) }

        return keyboardView
    }

    private fun processText(mode: AIEngine.Mode) {
        val ic: InputConnection = currentInputConnection ?: return
        val selectedText = ic.getSelectedText(0) ?: ""
        
        // If no text selected, try to get the whole line or last sentence
        val textToProcess = if (selectedText.isNotEmpty()) {
            selectedText.toString()
        } else {
            ic.getTextBeforeCursor(1000, 0)?.toString() ?: ""
        }

        if (textToProcess.isEmpty()) return

        scope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    aiEngine.process(textToProcess, mode)
                }
                
                if (selectedText.isNotEmpty()) {
                    ic.commitText(result, 1)
                } else {
                    // Replace the text before cursor
                    ic.deleteSurroundingText(textToProcess.length, 0)
                    ic.commitText(result, 1)
                }
            } catch (e: Exception) {
                // Handle error silently or show a small indicator
            }
        }
    }
}
