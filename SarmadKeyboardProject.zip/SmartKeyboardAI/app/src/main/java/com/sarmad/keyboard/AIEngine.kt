package com.sarmad.keyboard

import com.google.gson.Gson
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException

class AIEngine {

    enum class Mode {
        CORRECT, REFINE
    }

    private val client = OkHttpClient()
    private val gson = Gson()
    private val apiKey = "YOUR_OPENAI_API_KEY" // يجب استبداله بمفتاح حقيقي

    fun process(text: String, mode: Mode): String {
        val systemPrompt = when (mode) {
            Mode.CORRECT -> """
                أنت خبير في اللغة العربية. مهمتك هي تصحيح الأخطاء الإملائية والنحوية في النص العربي المقدم.
                القواعد الصارمة:
                1. حافظ تماماً على المعنى والأسلوب الأصلي للمستخدم.
                2. يمنع منعاً باتاً كتابة أي عبارات تمهيدية مثل (تفضل النص) أو (ها هو التعديل).
                3. يمنع وضع علامات تنصيص حول النص الناتج.
                4. أخرج النص المصحح فقط.
            """.trimIndent()
            
            Mode.REFINE -> """
                أنت أديب عربي بليغ. مهمتك هي تحويل النص العربي المقدم إلى أسلوب أدبي بليغ وفصيح يضاهي كتابات الأدباء المحترفين.
                القواعد الصارمة:
                1. ارتقِ باللغة واستخدم مفردات غنية وصياغة أدبية رفيعة.
                2. يمنع منعاً باتاً كتابة أي عبارات تمهيدية مثل (تفضل النص) أو (ها هو التعديل).
                3. يمنع وضع علامات تنصيص حول النص الناتج.
                4. أخرج النص المنسق فقط.
            """.trimIndent()
        }

        val requestBody = mapOf(
            "model" to "gpt-3.5-turbo",
            "messages" to listOf(
                mapOf("role" to "system", "content" to systemPrompt),
                mapOf("role" to "user", "content" to text)
            ),
            "temperature" to 0.3
        )

        val request = Request.Builder()
            .url("https://api.openai.com/v1/chat/completions")
            .addHeader("Authorization", "Bearer ${'$'}apiKey")
            .post(gson.toJson(requestBody).toRequestBody("application/json".toMediaType()))
            .build()

        return try {
            val response = client.newCall(request).execute()
            val responseBody = response.body?.string()
            if (response.isSuccessful && responseBody != null) {
                val jsonResponse = gson.fromJson(responseBody, OpenAIResponse::class.java)
                jsonResponse.choices.firstOrNull()?.message?.content?.trim() ?: text
            } else {
                text
            }
        } catch (e: IOException) {
            text
        }
    }

    data class OpenAIResponse(val choices: List<Choice>)
    data class Choice(val message: Message)
    data class Message(val content: String)
}
